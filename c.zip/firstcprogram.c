#include<stdio.h>
int main()
{
    printf("hey there");
    return 0;
}