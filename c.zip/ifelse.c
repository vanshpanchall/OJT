#include<stdio.h>
int main()
{
	int n = 1;

    switch(n)
    { case 1: printf("Case 1 it is");
    break;
    case 2: printf("case 2 it is");
    break;
    default: printf("no case is matching");
	}
	
}