#include<stdio.h>

int main(int argc, char const *argv[])
{
    /* code */
    int a, b;
    a=10;
    b=34;

    printf("10 + 34 = %d\n", a+b);
    printf("a - b = %d\n", a-b);
    printf("a * b = %d\n", a*b);
    printf("a / b = %d\n", a/b);
    return 0;
}
