// typecasting syntax
// (type)value;
#include <stdio.h>

int main()
{
    int a = 3;
    float b = (float)54 / 5;
    printf("The value of a is %f\n", b);
    return 0;
}