#include<iostream>
using namespace std;
int main()
{
	char ch='M';
	cout<<(int)ch;
}
