#include<iostream>
using namespace std;
int main()
{
	int a=16;
	int *ptr;
	ptr=&a;
	cout<<ptr<<endl;
	cout<<*ptr<<endl;
}
