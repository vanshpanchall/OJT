#include<iostream>
using namespace std;
int main()
{
	int a=65;
	float b=2.64;
	cout<<"the multiplication is: "<<a*b;
	return 0;
}
