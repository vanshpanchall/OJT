function demoexternalalert(){
    alert('Hello op1!');
}
function demoexternalconfirm()
{
    confirm('are you sure!');
}
function demoexternalprompt()
{
    prompt('eneter first name');}