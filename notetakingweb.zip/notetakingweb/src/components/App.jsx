import Footer from "./Footer";
import Heading from "./Heading";
import Note from "./Note";

const react = require("react");

function App() {
  return (
    <div>
      <Heading />
      <Note />
      <Note />
      <Note />
      <Note />
      <Footer />
    </div>
  );
}

export default App;
