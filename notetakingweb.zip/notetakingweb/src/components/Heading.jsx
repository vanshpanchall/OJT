const react = require("react");
const reactDOM = require("react-dom");

function Heading() {
  return (
    <header>
      <h1>NOTESTACK</h1>
    </header>
  );
}
export default Heading;
