import App from "./components/App";
const react = require("react");
const reactDOM = require("react-dom");

reactDOM.render(
  <div>
    <App />
  </div>,
  document.getElementById("root")
);
